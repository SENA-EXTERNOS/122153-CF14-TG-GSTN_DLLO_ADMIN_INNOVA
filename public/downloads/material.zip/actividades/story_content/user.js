function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5UnzqjqF6B4":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

